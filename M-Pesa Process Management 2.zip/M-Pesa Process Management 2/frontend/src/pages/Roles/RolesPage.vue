<template lang="">

  <div class="row q-pa-md bg-accent appearBox2" style="min-height: 100vh">
    <div class="col-8">
      <q-card class="bg-white q-pt-xl"  flat>
        <div class="image-avatar-1 bg-dark" style="border-radius: 100%; height: 150px; width: 150px">
          <img src="/team.png" style="position: absolute; object-position: fit; height: 70%; width: 70%">
        </div>

        <q-card-section class="text-center q-pt-sm text-dark">
          <div class="text-h6">User Roles</div>
          <div class="text-caption" style="max-width: 600px; margin: 0 auto">Define and manage the responsibilities and access levels of your team with the User Roles section. This feature allows you to assign specific roles to users, ensuring everyone has the appropriate permissions to perform their tasks effectively.</div>
        </q-card-section>
        <div>
          <q-input v-model="search"  filled bg-color="white" placeholder="search" dense type="search">
            <template v-slot:append>
              <q-icon name="search" />
            </template>
          </q-input>
          <q-separator color="grey-4"></q-separator>
        </div>

        <q-markup-table dense flat style="">
          <thead class="q-pt-md q-pb-md" >
            <tr>
              <th class="text-left">Dessert (100g serving)</th>
              <th class="text-right">Calories</th>
              <th class="text-right">Fat (g)</th>
              <th class="text-right">Carbs (g)</th>
              <th class="text-right">Protein (g)</th>
              <th class="text-right">Sodium (mg)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="text-left">Frozen Yogurt</td>
              <td class="text-right">159</td>
              <td class="text-right">6</td>
              <td class="text-right">24</td>
              <td class="text-right">4</td>
              <td class="text-right">87</td>
            </tr>
            <tr>
              <td class="text-left">Ice cream sandwich</td>
              <td class="text-right">237</td>
              <td class="text-right">9</td>
              <td class="text-right">37</td>
              <td class="text-right">4.3</td>
              <td class="text-right">129</td>
            </tr>
            <tr>
              <td class="text-left">Frozen Yogurt</td>
              <td class="text-right">159</td>
              <td class="text-right">6</td>
              <td class="text-right">24</td>
              <td class="text-right">4</td>
              <td class="text-right">87</td>
            </tr>
            <tr>
              <td class="text-left">Ice cream sandwich</td>
              <td class="text-right">237</td>
              <td class="text-right">9</td>
              <td class="text-right">37</td>
              <td class="text-right">4.3</td>
              <td class="text-right">129</td>
            </tr>
            <tr>
              <td class="text-left">Eclair</td>
              <td class="text-right">262</td>
              <td class="text-right">16</td>
              <td class="text-right">23</td>
              <td class="text-right">6</td>
              <td class="text-right">337</td>
            </tr>
            <tr>
              <td class="text-left">Cupcake</td>
              <td class="text-right">305</td>
              <td class="text-right">3.7</td>
              <td class="text-right">67</td>
              <td class="text-right">4.3</td>
              <td class="text-right">413</td>
            </tr>
            <tr>
              <td class="text-left">Gingerbread</td>
              <td class="text-right">356</td>
              <td class="text-right">16</td>
              <td class="text-right">49</td>
              <td class="text-right">3.9</td>
              <td class="text-right">327</td>
            </tr>
          </tbody>
        </q-markup-table>
      </q-card>
    </div>
    <div class="col-4 q-pl-md">
      <q-card flat class=" bg-dark text-white">
        <q-card-section>
          <div class="text-h6">User Roles</div>
        </q-card-section>

        <div class="q-gutter-sm q-pl-md text-caption q-pb-md" style="display: flex; flex-direction: column">
          <q-checkbox dense v-model="checked" dark label="Admin" color="secondary" />
          <q-checkbox dense v-model="checked" dark label="View Access" color="secondary" />
          <q-checkbox dense v-model="checked" dark label="Approver" color="secondary" />
          <q-checkbox dense v-model="checked" dark label="View Dashbord" color="secondary" />
          <q-checkbox dense v-model="checked" dark label="Audit log" color="secondary" />
        </div>

        <q-card-actions>
          <q-space></q-space><q-btn color="grey-3" flat label="Save" align="left"   icon="save" />
          <q-btn flat color="grey-3" label="Reset" align="left"    />
        </q-card-actions>
      </q-card>
      <q-card flat class=" bg-white text-dark q-mt-md q-pt-md">
        <div class="image-avatar-1 bg-secondary" style="border-radius: 100%; ">
          <img src="/programmer.png" style="position: absolute; object-position: fit; height: 60%; width: 60%">
        </div>

        <q-card-section class="text-center q-pt-sm text-dark">
          <div class="text-h6">Marcos Costa</div>
          <div class="text-caption">marcos.costa@gmail.com</div>
        </q-card-section>
      </q-card>
      <q-card flat class=" bg-white text-dark q-mt-md q-pt-md">
        <div class="image-avatar-1 bg-secondary" style="border-radius: 100%; ">
          <img src="/unlocked.png" style="position: absolute; object-position: fit; height: 60%; width: 60%">
        </div>

        <q-card-section class="text-center q-pt-sm text-dark">
          <div class="text-h6">Deactivate Account</div>

          <q-btn color="white" flat no-caps  text-color="secondary" label="Deactivate" />
        </q-card-section>
      </q-card>
    </div>
  </div>
</template>
<script>
import { ref } from 'vue'

export default {
  setup () {
    return {
      checked: ref(false),
    }
  }
}
</script>
<style lang="scss">
.image-avatar-1 {

  border-radius: 50px 20px;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100px;
  width: 100px;
  margin: 0 auto;
  padding-left: 4px;
}
</style>
